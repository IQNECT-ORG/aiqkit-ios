//
//  IQNavigationController.h
//  AIQ
//
//  Created by Ricardo Santos on 1/08/2014.
//  Copyright (c) 2014 NextFaze Pty Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface iQNavigationController : UINavigationController

@end
